/*  
 * JCE Editor                 2.2.9.1
 * @package                 JCE
 * @url                     http://www.joomlacontenteditor.net
 * @copyright               Copyright (C) 2006 - 2012 Ryan Demmer. All rights reserved
 * @license                 GNU/GPL Version 2 or later - http://www.gnu.org/licenses/gpl-2.0.html
 * @date                    10 November 2012
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.

 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * NOTE : Javascript files have been compressed for speed and can be uncompressed using http://jsbeautifier.org/
 */
(function(){var DOM=tinymce.DOM,Element=tinymce.dom.Element,Event=tinymce.dom.Event,each=tinymce.each,is=tinymce.is;tinymce.create('tinymce.plugins.InlinePopups',{init:function(ed,url){ed.onBeforeRenderUI.add(function(){ed.windowManager=new tinymce.InlineWindowManager(ed);if(!ed.settings.compress.css){DOM.loadCSS(ed.settings.jquery_ui);DOM.loadCSS(url+'/css/dialog.css');}});},getInfo:function(){return{longname:'InlinePopups',author:'Moxiecode Systems AB',authorurl:'http://tinymce.moxiecode.com',infourl:'http://wiki.moxiecode.com/index.php/TinyMCE:Plugins/inlinepopups',version:tinymce.majorVersion+"."+tinymce.minorVersion};}});tinymce.create('tinymce.InlineWindowManager:tinymce.WindowManager',{InlineWindowManager:function(ed){var t=this;t.parent(ed);t.zIndex=300000;t.count=0;t.windows={};},open:function(f,p){var t=this,id,opt='',ed=t.editor,dw=0,dh=0,vp,po,mdf,clf,we,w,u,parentWindow;f=f||{};p=p||{};if(!f.inline)
return t.parent(f,p);parentWindow=t._frontWindow();if(parentWindow&&DOM.get(parentWindow.id+'_ifr')){parentWindow.focussedElement=DOM.get(parentWindow.id+'_ifr').contentWindow.document.activeElement;}
if(!f.type)
t.bookmark=ed.selection.getBookmark(1);id=DOM.uniqueId();vp=DOM.getViewPort();f.width=parseInt(f.width||320);f.height=parseInt(f.height||240)+(tinymce.isIE?8:0);f.min_width=parseInt(f.min_width||150);f.min_height=parseInt(f.min_height||100);f.max_width=parseInt(f.max_width||2000);f.max_height=parseInt(f.max_height||2000);f.left=f.left||Math.round(Math.max(vp.x,vp.x+(vp.w/2.0)-(f.width/2.0)));f.top=f.top||Math.round(Math.max(vp.y,vp.y+(vp.h/2.0)-(f.height/2.0)));f.movable=f.resizable=true;p.mce_width=f.width;p.mce_height=f.height;p.mce_inline=true;p.mce_window_id=id;p.mce_auto_focus=f.auto_focus;t.features=f;t.params=p;t.onOpen.dispatch(t,f,p);if(f.type){if(f.type)
opt+=' ui-dialog-'+f.type.substring(0,1)+f.type.substring(1);f.resizable=false;}
var title=f.title||'';var wrapper=DOM.get('ui-jce-wrapper');if(!wrapper){this.count=0;wrapper=DOM.add(DOM.doc.body,'div',{'id':'ui-jce-wrapper','class':'ui-jce'});}
t._addAll(wrapper,['div',{id:id,role:'dialog','aria-labelledby':f.type?id+'_content':id+'_title',tabindex:-1,'class':'ui-dialog ui-widget ui-widget-content ui-corner-all ui-draggable ui-resizable'+opt},['div',{'class':'ui-dialog-titlebar ui-widget-header ui-corner-all ui-helper-clearfix'},['span',{id:id+'_title','class':'ui-dialog-title'},f.title||''],['a',{href:'#','class':'ui-dialog-titlebar-close ui-corner-all',role:'button'},['span',{'class':'ui-icon ui-icon-closethick'},'close']]],['div',{id:id+'_content','class':'ui-dialog-content ui-widget-content',style:'overflow:hidden;'}],['div',{'class':'ui-resizable-handle ui-resizable-n'}],['div',{'class':'ui-resizable-handle ui-resizable-s'}],['div',{'class':'ui-resizable-handle ui-resizable-w'}],['div',{'class':'ui-resizable-handle ui-resizable-e'}],['div',{'class':'ui-resizable-handle ui-resizable-nw'}],['div',{'class':'ui-resizable-handle ui-resizable-ne'}],['div',{'class':'ui-resizable-handle ui-resizable-sw'}],['div',{'class':'ui-resizable-handle ui-resizable-se ui-icon ui-icon-gripsmall-diagonal-se ui-icon-grip-diagonal-se'}]]);DOM.setStyles(id,{top:-10000,left:-10000});DOM.addClass(id,'loading');if(!f.type){dh+=DOM.get(id).clientHeight;f.min_height=f.height+dh;}
DOM.setStyles(id,{top:f.top,left:f.left,width:f.width+dw,height:f.height+dh});u=f.url||f.file;if(u){if(tinymce.relaxedDomain)
u+=(u.indexOf('?')==-1?'?':'&')+'mce_rdomain='+tinymce.relaxedDomain;u=tinymce._addVer(u);}
if(!f.type){var iframe=DOM.add(id+'_content','iframe',{id:id+'_ifr',src:'javascript:""',frameBorder:0,style:'border:0;width:10px;height:10px'});DOM.setStyles(iframe,{width:f.width,height:f.height});DOM.setAttrib(iframe,'src',u);Event.add(iframe,'load',function(){DOM.removeClass(id,'loading');});}else{var pane=DOM.add(id,'div',{'class':'ui-dialog-buttonpane ui-widget-content ui-helper-clearfix'});var set=DOM.add(pane,'div',{'class':'ui-dialog-buttonset'});DOM.add(set,'button',{type:'button',id:id+'_ok','class':'ui-button ui-widget ui-state-default ui-corner-all ui-button-text-only ui-button-ok','role':'button','aria-disabled':false,'aria-labelledby':id+'_ok_text'},'<span class="ui-button-text" id="'+id+'_ok_text">'+ed.getLang('ok','OK')+'</span>');if(f.type=='confirm'){DOM.add(set,'button',{type:'button',id:id+'_cancel','class':'ui-button ui-widget ui-state-default ui-corner-all ui-button-text-only ui-button-cancel','role':'button','aria-disabled':false,'aria-labelledby':id+'_ok_text'},'<span class="ui-button-text" id="'+id+'_cancel_text">'+ed.getLang('cancel','Cancel')+'</span>');}
DOM.setHTML(id+'_content','<span class="ui-icon ui-icon-'+f.type+'"></span>'+f.content.replace('\n','<br />'));Event.add(id,'keyup',function(evt){var VK_ESCAPE=27;if(evt.keyCode===VK_ESCAPE){f.button_func(false);return Event.cancel(evt);}});Event.add(id,'keydown',function(evt){var cancelButton,VK_TAB=9;if(evt.keyCode===VK_TAB){cancelButton=DOM.get(id+'_cancel');if(cancelButton&&cancelButton!==evt.target){cancelButton.focus();}else{DOM.get(id+'_ok').focus();}
return Event.cancel(evt);}});}
mdf=Event.add(id,'mousedown',function(e){var n=e.target,ac;t.focus(id);if(DOM.hasClass(n,'ui-dialog-title')){n=n.parentNode;}
if(DOM.hasClass(n,'ui-dialog-titlebar')){ac='move';return t._startDrag(id,e,ac);}
if(DOM.hasClass(n,'ui-resizable-handle')){ac=/ui-resizable-(ne|nw|se|sw|n|s|e|w)/.exec(n.className);if(ac)
return t._startDrag(id,e,ac[1]);}});Event.add([id+'_left',id+'_right'],'focus',function(evt){var iframe=DOM.get(id+'_ifr');if(iframe){var body=iframe.contentWindow.document.body;var focusable=DOM.select(':input:enabled,*[tabindex=0]',body);focusable[0].focus();}else{DOM.get(id+'_ok').focus();}});clf=Event.add(id,'click',function(e){var n=e.target;t.focus(id);if(DOM.is(n,'.ui-button-cancel, .ui-button-cancel span, .ui-button-ok, .ui-button-ok span')){f.button_func(DOM.is(n,'.ui-button-ok, .ui-button-ok span'));}else if(DOM.is(n,'.ui-dialog-titlebar-close, .ui-dialog-titlebar-close span')){t.close(null,id);}
return Event.cancel(e);});Event.add(DOM.select('.ui-dialog-titlebar-close',id),'mouseover',function(e){var n=e.target;if(n.nodeName!='A'){n=n.parentNode;}
DOM.addClass(n,'ui-state-hover');});Event.add(DOM.select('.ui-dialog-titlebar-close',id),'mouseout',function(e){var n=e.target;if(n.nodeName!='A'){n=n.parentNode;}
DOM.removeClass(n,'ui-state-hover');});Event.add(DOM.select('.ui-dialog-titlebar-close',id),'focus',function(e){var n=e.target;if(n.nodeName!='A'){n=n.parentNode;}
DOM.addClass(n,'ui-state-focus');});Event.add(DOM.select('.ui-dialog-titlebar-close',id),'blur',function(e){var n=e.target;if(n.nodeName!='A'){n=n.parentNode;}
DOM.removeClass(n,'ui-state-focus');});w=t.windows[id]={id:id,mousedown_func:mdf,click_func:clf,element:new Element(id,{blocker:1,container:ed.getContainer()}),iframeElement:new Element(id+'_ifr'),features:f,deltaWidth:dw,deltaHeight:dh};w.iframeElement.on('focus',function(){t.focus(id);});var overlay=DOM.get('ui-widget-overlay');if(!overlay){overlay=DOM.add(wrapper,'div',{id:'ui-widget-overlay','class':'ui-widget-overlay',style:{position:'fixed',left:0,top:0,width:'100%',height:'100%',zIndex:t.zIndex-1}});DOM.show(overlay);DOM.setAttrib(DOM.doc.body,'aria-hidden','true');}
DOM.setAttrib(id,'aria-hidden','false');if(tinymce.isIE6||(tinymce.isIE&&!DOM.boxModel)){DOM.setStyles(overlay,{position:'absolute',left:vp.x,top:vp.y,width:vp.w-2,height:vp.h-2});}
t.focus(id);this.count++;return w;},focus:function(id){var t=this,w;if(w=t.windows[id]){w.zIndex=this.zIndex++;w.element.setStyle('zIndex',w.zIndex);w.element.update();DOM.removeClass(t.lastId,'ui-dialog-focus');DOM.addClass(id,'ui-dialog-focus');t.lastId=id;if(w.focussedElement){w.focussedElement.focus();}else if(DOM.get(id+'_ok')){DOM.get(w.id+'_ok').focus();}else if(DOM.get(w.id+'_ifr')){DOM.get(w.id+'_ifr').focus();}}},_addAll:function(te,ne){var i,n,t=this,dom=tinymce.DOM;if(is(ne,'string'))
te.appendChild(dom.doc.createTextNode(ne));else if(ne.length){te=te.appendChild(dom.create(ne[0],ne[1]));for(i=2;i<ne.length;i++)
t._addAll(te,ne[i]);}},_startDrag:function(id,se,ac){var t=this,mu,mm,d=DOM.doc,eb,w=t.windows[id],we=w.element,sp=we.getXY(),p,sz,ph,cp,vp,sx,sy,sex,sey,dx,dy,dw,dh;cp={x:0,y:0};vp=DOM.getViewPort();vp.w-=2;vp.h-=2;sex=se.screenX;sey=se.screenY;dx=dy=dw=dh=0;mu=Event.add(d,'mouseup',function(e){Event.remove(d,'mouseup',mu);Event.remove(d,'mousemove',mm);DOM.removeClass(id,'ui-dialog-dragging');if(eb)
eb.remove();we.moveBy(dx,dy);we.resizeBy(dw,dh);sz=we.getSize();DOM.setStyles(id+'_ifr',{width:sz.w-w.deltaWidth,height:sz.h-w.deltaHeight});return Event.cancel(e);});if(ac!='move')
startMove();function startMove(){if(eb)
return;DOM.addClass(id,'ui-dialog-dragging');var blocker=DOM.add(DOM.get('ui-jce-wrapper'),'div',{id:'ui-dialog-blocker','class':'ui-widget ui-dialog-blocker',style:{zIndex:t.zIndex+1}});if(tinymce.isIE6||(tinymce.isIE&&!DOM.boxModel))
DOM.setStyles(blocker,{position:'absolute',left:vp.x,top:vp.y,width:vp.w-2,height:vp.h-2});eb=new Element(blocker);eb.update();sz={w:DOM.get(id).clientWidth,h:DOM.get(id).clientHeight};sx=cp.x+sp.x-vp.x;sy=cp.y+sp.y-vp.y;DOM.add(eb.get(),'div',{id:'ui-dialog-placeholder','class':'ui-widget-content ui-widget-overlay',style:{left:sx,top:sy,width:sz.w,height:sz.h}});ph=new Element('ui-dialog-placeholder');};mm=Event.add(d,'mousemove',function(e){var x,y,v;startMove();x=e.screenX-sex;y=e.screenY-sey;switch(ac){case'w':dx=x;dw=0-x;break;case'e':dw=x;break;case'n':case'nw':case'ne':if(ac=="nw"){dx=x;dw=0-x;}else if(ac=="ne")
dw=x;dy=y;dh=0-y;break;case's':case'sw':case'se':if(ac=="sw"){dx=x;dw=0-x;}else if(ac=="se")
dw=x;dh=y;break;case'move':dx=x;dy=y;break;}
if(dw<(v=w.features.min_width-sz.w)){if(dx!==0)
dx+=dw-v;dw=v;}
if(dh<(v=w.features.min_height-sz.h)){if(dy!==0)
dy+=dh-v;dh=v;}
dw=Math.min(dw,w.features.max_width-sz.w);dh=Math.min(dh,w.features.max_height-sz.h);dx=Math.max(dx,vp.x-(sx+vp.x));dy=Math.max(dy,vp.y-(sy+vp.y));dx=Math.min(dx,(vp.w+vp.x)-(sx+sz.w+vp.x));dy=Math.min(dy,(vp.h+vp.y)-(sy+sz.h+vp.y));if(dx+dy!==0){if(sx+dx<0)
dx=0;if(sy+dy<0)
dy=0;ph.moveTo(sx+dx,sy+dy);}
if(dw+dh!==0)
ph.resizeTo(sz.w+dw,sz.h+dh);return Event.cancel(e);});return Event.cancel(se);},resizeBy:function(dw,dh,id){var w=this.windows[id];if(w){w.element.resizeBy(dw,dh);w.iframeElement.resizeBy(dw,dh);}},close:function(win,id){var t=this,w,d=DOM.doc,ix=0,fw,id;id=t._findId(id||win);if(!t.windows[id]){t.parent(win);return;}
if(w=t.windows[id]){t.onClose.dispatch(t);Event.remove(d,'mousedown',w.mousedownFunc);Event.remove(d,'click',w.clickFunc);Event.clear(id);Event.clear(id+'_ifr');DOM.setAttrib(id+'_ifr','src','javascript:""');w.element.remove();delete t.windows[id];fw=t._frontWindow();if(fw)
t.focus(fw.id);this.count--;if(fw)
t.focus(fw.id);}
if(this.count==0){DOM.remove('ui-jce-wrapper');DOM.setAttrib(DOM.doc.body,'aria-hidden','false');}},alert:function(txt,cb,s){var t=this,w;w=t.open({title:t,type:'alert',button_func:function(s){if(cb)
cb.call(t,s);t.close(null,w.id);},content:DOM.encode(t.editor.getLang(txt,txt)),inline:1,width:400,height:150});},confirm:function(txt,cb,s){var t=this,w;w=t.open({title:t,type:'confirm',button_func:function(s){if(cb)
cb.call(t,s);t.close(null,w.id);},content:DOM.encode(t.editor.getLang(txt,txt)),inline:1,width:400,height:150});},setTitle:function(w,ti){var e;w=this._findId(w);if(e=DOM.get(w+'_title'))
e.innerHTML=DOM.encode(ti);},_frontWindow:function(){var fw,ix=0;each(this.windows,function(w){if(w.zIndex>ix){fw=w;ix=w.zIndex;}});return fw;},_findId:function(w){var t=this;if(typeof(w)=='string')
return w;each(t.windows,function(wo){var ifr=DOM.get(wo.id+'_ifr');if(ifr&&w==ifr.contentWindow){w=wo.id;return false;}});return w;}});tinymce.PluginManager.add('inlinepopups',tinymce.plugins.InlinePopups);})();